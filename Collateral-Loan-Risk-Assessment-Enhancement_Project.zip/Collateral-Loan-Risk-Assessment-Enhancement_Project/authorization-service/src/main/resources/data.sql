insert into user(id, name, password) values (1, 'mahima', 'abc1');
insert into user(id, name, password) values (2, 'adyasha', 'abc2');
insert into user(id, name, password) values (3, 'vishal', 'abc3');
insert into user(id, name, password) values (4, 'pradaap', 'abc4');
insert into user(id,name,password) values(6,'user','user1');
insert into user(id,name,password) values(7,'admin','admin1');